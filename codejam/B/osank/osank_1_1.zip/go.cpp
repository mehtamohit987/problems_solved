# include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int,int> pii;
typedef vector<int> vi;

#define s(n)                        scanf("%d",&n)
#define p(n)                        printf("%d\n",n)
#define all(n)                      for(int i=0;i<n;i++)
#define pb                          push_back
#define mp                          make_pair
#define all1(a)                     a.begin(), a.end()

int a,b,i,j,k,n,m,t,ar[1001][1001],cases,x,y,prev,flag;
string ch;

int main()
{
	    freopen("in.txt","r",stdin);
		freopen("out.txt","w",stdout);


s(cases);
for(t=1;t<=cases;t++)
{

	s(n);
	cin>>ch;
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			s(ar[i][j]);


		if(ch=="right")
		{
			
			for(i=0;i<n;i++){
				flag=0;
				for(j=n-1;j>=0;j--){
					if(ar[i][j]!=0){
						if(!flag)
						{
							//cout<<"yo";
							prev=ar[i][j];
							x=i;
							y=j;
							flag=1;
						}
						else
						{
							//cout<<"yo";
							if(prev==ar[i][j]){
								ar[x][y]*=2;
								ar[i][j]=0;
								flag=0;
							}
							else
							{
								//cout<<"yo1";
								prev=ar[i][j];
								x=i;
								y=j;
							}
						}
					}

				}
			}

			for(i=0;i<n;i++){
				for(k=0;k<n;k++)
				for(j=0;j<n-1;j++){
					if(ar[i][j]!=0&&ar[i][j+1]==0){
						swap(ar[i][j],ar[i][j+1]);

					}
				}
			}


		}


		if(ch=="left")
		{
			
			for(i=0;i<n;i++){
				flag=0;
				for(j=0;j<n ;j++){
					if(ar[i][j]!=0){
						if(!flag)
						{
							//cout<<"yo";
							prev=ar[i][j];
							x=i;
							y=j;
							flag=1;
						}
						else
						{
							//cout<<"yo";
							if(prev==ar[i][j]){
								ar[x][y]*=2;
								ar[i][j]=0;
								flag=0;
							}
							else
							{
								//cout<<"yo1";
								prev=ar[i][j];
								x=i;
								y=j;
							}
						}
					}

				}
			}

			for(i=0;i<n;i++){
				for(k=0;k<n;k++)
				for(j=n-1;j>0;j--){
					if(ar[i][j-1]==0&&ar[i][j]!=0){
						swap(ar[i][j],ar[i][j-1]);

					}
				}
			}


		}

		if(ch=="up")
		{
			
			for(j=0;j<n;j++){
				flag=0;
				for(i=0;i<n;i++){
					if(ar[i][j]!=0){
						if(!flag)
						{
							//cout<<"yo";
							prev=ar[i][j];
							x=i;
							y=j;
							flag=1;
						}
						else
						{
							//cout<<"yo";
							if(prev==ar[i][j]){
								ar[x][y]*=2;
								ar[i][j]=0;
								flag=0;
							}
							else
							{
								//cout<<"yo1";
								prev=ar[i][j];
								x=i;
								y=j;
							}
						}
					}

				}
			}

			for(j=0;j<n;j++){
				for(k=0;k<n;k++)
				for(i=n-1;i>0;i--){
					if(ar[i-1][j]==0&&ar[i][j]!=0){
						swap(ar[i][j],ar[i-1][j]);

					}
				}
			}


		}

		if(ch=="down")
		{
			
			for(j=0;j<n;j++){
				flag=0;
				for(i=n-1;i>=0;i--){
					if(ar[i][j]!=0){
						if(!flag)
						{
							//cout<<"yo";
							prev=ar[i][j];
							x=i;
							y=j;
							flag=1;
						}
						else
						{
							//cout<<"yo";
							if(prev==ar[i][j]){
								ar[x][y]*=2;
								ar[i][j]=0;
								flag=0;
							}
							else
							{
								//cout<<"yo1";
								prev=ar[i][j];
								x=i;
								y=j;
							}
						}
					}

				}
			}

			for(j=0;j<n;j++){
				for(k=0;k<n;k++)
				for(i=0;i<n-1;i++){
					if(ar[i][j]!=0&&ar[i+1][j]==0){
						swap(ar[i][j],ar[i+1][j]);

					}
				}
			}


		}		





	

	printf("Case #%d:\n",t);

	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			cout<<ar[i][j]<<" ";

		}
		cout<<"\n";
	}

}	


	return 0;
}
